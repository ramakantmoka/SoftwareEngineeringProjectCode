#include "hello.h"


#include "UnitTestMessages_copied.h"

static int32_t  hello_blockexpr_main_7(void);

int32_t  hello_add(void) 
{
  int32_t ___failuresVal = 0;
  int32_t *___failures = &___failuresVal;
  UnitTestMessages_copied____testing_runningTest("hello:add?r:9b1aa3af-d1f1-4b0c-a1d4-3994d9fa582b(NewSolution.Main.main)#7788983545940045896");
  
  if ( !(1 + 2 == 5) ) 
  {
    (*___failures)++;;
    UnitTestMessages_copied____testing_FAILED(0, "hello:add?r:9b1aa3af-d1f1-4b0c-a1d4-3994d9fa582b(NewSolution.Main.main)#7788983545940045917");
    
  }
  return ___failuresVal;
}

static int32_t  hello_blockexpr_main_7(void) 
{
  int32_t ___failuresVal = 0;
  int32_t *___failures = &___failuresVal;
  *___failures = *___failures + hello_add();
  return ___failuresVal;
}

int32_t  main(int32_t argc, char *(argv[])) 
{
  if ( true ) 
  {
    1;
  }
  return hello_blockexpr_main_7();
}

