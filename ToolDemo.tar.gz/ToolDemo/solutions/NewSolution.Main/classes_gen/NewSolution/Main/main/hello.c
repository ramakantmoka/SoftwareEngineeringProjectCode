#include "hello.h"


#include "UnitTestMessages_copied.h"

static int32_t  hello_blockexpr_main_7(void);

int32_t  hello_add(void) 
{
  int32_t ___failuresVal = 0;
  int32_t *___failures = &___failuresVal;
  UnitTestMessages_copied____testing_runningTest("hello:add?r:d2fe1d87-55e2-415b-948b-b2916db513a9(NewSolution.Main.main)#8061060663430906803");
  
  if ( !(1 + 2 == 4) ) 
  {
    (*___failures)++;;
    UnitTestMessages_copied____testing_FAILED(0, "hello:add?r:d2fe1d87-55e2-415b-948b-b2916db513a9(NewSolution.Main.main)#8061060663430911654");
    
  }
  return ___failuresVal;
}

static int32_t  hello_blockexpr_main_7(void) 
{
  int32_t ___failuresVal = 0;
  int32_t *___failures = &___failuresVal;
  *___failures = *___failures + hello_add();
  return ___failuresVal;
}

int32_t  main(int32_t argc, char *(argv[])) 
{
  if ( true ) 
  {
    1;
  }
  return hello_blockexpr_main_7();
}

